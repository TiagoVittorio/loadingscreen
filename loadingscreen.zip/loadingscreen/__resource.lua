resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'
files {
 
	'assets/music.mp3',
	'style.css',
	'assets/style/cursor.css',
	'index.html',
	'js/main.js',
    'js/plugins.js',
    'assets/img/gangster.gif',
    'assets/img/police_car.gif',
    'assets/img/runner.gif',
    'assets/img/bg.png'

}

loadscreen 'index.html'
